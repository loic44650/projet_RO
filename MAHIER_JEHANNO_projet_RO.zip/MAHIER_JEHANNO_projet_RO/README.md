# projet_RO


# Compilation :
________________________


pour suprimer les fichiers créés à la compilation et à l'exécution :
make clean

pour compiler :
make




# Exécution :
________________________


pour exécuter le programme avec le jeu de données servant d'exemple dans le sujet :
./main.exe data/exemple.dat

pour exécuter le programme avec les jeux de données VRPA :
./main.exe data/A/VRPB10.dat

pour exécuter le programme avec les jeux de données VRPB:
./main.exe data/B/VRPB10.dat 
